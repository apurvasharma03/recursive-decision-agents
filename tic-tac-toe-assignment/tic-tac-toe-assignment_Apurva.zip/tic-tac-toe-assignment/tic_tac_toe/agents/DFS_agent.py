from pprint import pprint

from ..board import Board, CellState
from .base_agent import Agent, Move, valid_moves
from ..player import Player, PLAYER_NAMES
import sys


class DFSAgent(Agent):
    def __init__(self, player):
        super().__init__(player)
        super().__init__(Board)
        self._board = Board(size=3, num_to_win=None)
        #valid = True

    def next_move(self, board):
        def _input_move():
            try:
                """
                print("")
                print("{}'s next move".format(PLAYER_NAMES[self._player]))
                row = int(input("\trow: "))
                col = int(input("\tcol: "))
                print("")

                return Move(self._player, row, col)
                """
                #stack = []
                valid = True
                bestScore = -5
                #finalMove = Move(self._player, 0, 0)
                #print("recursion limit: " + str(sys.getrecursionlimit()))
                sys.setrecursionlimit(2200)
                #print("recursion limit: " + str(sys.getrecursionlimit()))
                for i in range(3):
                    for j in range(3):
                        if (Move(self._player, i, j) not in valid_moves(board, self._player)):
                            valid = False
                            print("inside first if")
                            finalMove = Move(self._player, 0, 0)
                        if (valid):
                            print("inside second if")
                            testMove = Move(self._player, i, j)
                            score = minimax(testMove, 0, False)
                            if (score > bestScore):
                                print("score > best score")
                                bestScore = score
                                finalMove = Move(self._player, i, j)
                            else:
                                finalMove = Move(self._player, 0, 0)
                return finalMove
            except ValueError:
                print("Row an col must be integers between 0 and {}".format(
                    board.size))

        
        def minimax(testMove, depth, isMax):
            print("inside minimax")
            valid = True
            # if it is at an end state, return the score
            #if winner(self._player)
            
            win = False
            if (self._player == "x"):
                score = 1
                win = True
            elif (self._player == "o"):
                score = -1
                win = True
            elif (self._player == "draw"):
                score = 0
                win = True
            
            if (win):
                print("return score")
                return score
            
        
            if (isMax):
                print("inside isMax")
                for i in range(3):
                    for j in range(3):
                        print("inside isMax loop")
                        if (Move(self._player, i, j) not in valid_moves(board, self._player)):
                            valid = False
                        if (valid):
                            testMove = Move(self._player, i, j)
                            score = minimax(testMove, depth + 1, False)
                            if (score > bestScore):
                                print("score > bestscore inside minimax")
                                bestScore = score
                                finalMove = Move(self._player, i, j)
                return bestScore
            else:
                print("inside else")
                for i in range(3):
                    for j in range(3):
                        if (Move(self._player, i, j) not in valid_moves(board, self._player)):
                            valid = False
                        if (valid):
                            print("inside valid else")
                            testMove = Move(self._player, i, j)
                            score = minimax(testMove, depth + 1, False)
                            if (score > bestScore):
                                bestScore = score
                                finalMove = Move(self._player, i, j)
                return bestScore

        move = _input_move()
        next_moves = valid_moves(board, self._player)

        """
        while move not in next_moves:
            print("{} is not valid, try again.".format(move))
            print("Valid moves: ")
            pprint(next_moves)
            move = _input_move()
        """

        return move
